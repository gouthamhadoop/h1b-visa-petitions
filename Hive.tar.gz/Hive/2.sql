use niit;
select worksite,total,year from(select worksite,count(job_title)as total,year from h1b_final where job_title="DATA ENGINEER" and year='2011' group by worksite,year order by total desc limit 1)sub1 
union
select worksite,total,year from(select worksite,count(job_title)as total,year from h1b_final where job_title="DATA ENGINEER" and year='2012' group by worksite,year order by total desc limit 1)sub2 
union
select worksite,total,year from(select worksite,count(job_title)as total,year from h1b_final where job_title="DATA ENGINEER" and year='2013' group by worksite,year order by total desc limit 1)sub3 
union
select worksite,total,year from(select worksite,count(job_title)as total,year from h1b_final where job_title="DATA ENGINEER" and year='2014' group by worksite,year order by total desc limit 1)sub4
union
select worksite,total,year from(select worksite,count(job_title)as total,year from h1b_final where job_title="DATA ENGINEER" and year='2015' group by worksite,year order by total desc limit 1)sub5
union
select worksite,total,year from(select worksite,count(job_title)as total,year from h1b_final where job_title="DATA ENGINEER" and year='2016' group by worksite,year order by total desc limit 1)sub6 
order by year;
