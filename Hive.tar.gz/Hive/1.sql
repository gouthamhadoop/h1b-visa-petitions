use niit;
select soc_name,job_title,case_status,count(*)as a from h1b_final where case_status="CERTIFIED" and job_title="DATA SCIENTIST" group by soc_name,job_title,case_status order by a desc limit 1;
