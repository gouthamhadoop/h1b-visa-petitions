use niit;
select job_title,full_time_position,avg(prevailing_wage) from h1b_final where case_status="CERTIFIED" or case_status="CERTIFIED-WITHDRAWN" group by job_title,full_time_position;

